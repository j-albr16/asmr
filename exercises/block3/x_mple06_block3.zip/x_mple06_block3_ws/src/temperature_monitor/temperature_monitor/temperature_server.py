from tempmon_interfaces.srv import GetTemperature, SetTemperature

import random
import rclpy
from rclpy.node import Node


class TemperatureServer(Node):

    def __init__(self):
        super().__init__('temperature_server')
        self.current_temperature = 22.5
        self.get_temperature = self.create_service(GetTemperature, 'get_temperature', self.get_temperature_callback)
        self.set_temperature = self.create_service(SetTemperature, 'set_temperature', self.set_temperature_callback)
        self.timer = self.create_timer(1.0, self.timer_callback)  # one second timer
        self.get_logger().info('TemperatureServer is ready')


    def get_temperature_callback(self, request, response):
        response.current_temperature = self.current_temperature
        self.get_logger().info('Temperature requested - currently at: %f' % (response.current_temperature))
        response.success = True
        return response


    def set_temperature_callback(self, request, response):
        if not isinstance(request.set_temperature, (int, float)):
            response.success = False
            self.get_logger().error('Invalid set_temperature value received: %s' % str(request.set_temperature))
        else:
            self.current_temperature = request.new_temperature
            self.get_logger().info('Setting new temperature to: %f' % (request.new_temperature))
            response.success = True
        return response
    

    def timer_callback(self):
        # changes the temperature randomly between -1.0 and 1.0
        self.current_temperature += (random.random() - 0.5) * 2.0
        self.get_logger().info('Current temperature: %f' % (self.current_temperature))


def main(args=None):
    rclpy.init(args=args)
    temperature_server = TemperatureServer()
    rclpy.spin(temperature_server)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
