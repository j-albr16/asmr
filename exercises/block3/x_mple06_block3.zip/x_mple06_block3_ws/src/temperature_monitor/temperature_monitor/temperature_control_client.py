from tempmon_interfaces.srv import GetTemperature, SetTemperature

import rclpy
from rclpy.node import Node


class TemperatureControlClient(Node):

    def __init__(self):
        super().__init__('temperature_control_client')

        self.get_cli = self.create_client(GetTemperature, 'get_temperature')
        self.set_cli = self.create_client(SetTemperature, 'set_temperature')
        while not self.get_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        while not self.set_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.get_req = GetTemperature.Request()
        self.set_req = SetTemperature.Request()
        self.get_future = None  # Initialize the Futures to keep track of the response
        self.set_future = None

        self.timer = self.create_timer(4.0, self.timer_callback)
        self.min_temperature = 20.0  # Those could alternatively be read from a parameter
        self.max_temperature = 25.0
        self.save_temperature = (self.min_temperature + self.max_temperature) / 2.0
        self.get_logger().info('TemperatureControlClient is ready')


    def timer_callback(self):
        if self.set_future is not None:
            if self.set_future.done():
                self.handle_set_response(self.set_future.result())
            else:
                self.get_logger().info('Waiting for response...')
        elif self.get_future is None:
            self.send_get_request()
        elif self.get_future.done():
            self.handle_get_response(self.get_future.result())
        else:
            self.get_logger().info('Waiting for response...')


    def send_get_request(self):
        self.get_logger().info('Sending request to get temperature...')
        self.get_future = self.get_cli.call_async(self.get_req)


    def send_set_request(self):
        self.get_logger().info('Sending request to set temperature to %f ...' % self.save_temperature)
        self.set_req.new_temperature = self.save_temperature
        self.set_future = self.set_cli.call_async(self.set_req)


    def handle_get_response(self, response):
        if response is None:
            self.get_logger().error('Exception while calling get_temperature service: %s' % self.get_future.exception())
        elif response is not None and response.success:
            self.check_temperature(response.current_temperature)
        else:
            self.get_logger().warning('Service call failed or returned an invalid response')
        self.get_future = None  # Resetting the Future for next call


    def handle_set_response(self, response):
        if response is None:
            self.get_logger().error('Exception while calling set_temperature service: %s' % self.set_future.exception())
        elif response is not None and response.success:
            self.get_logger().info('Temperature set successfully')
        else:
            self.get_logger().warning('Temperature setting failed')
        self.set_future = None  # Resetting the Future for next call


    def check_temperature(self, current_temperature):
        if current_temperature > self.max_temperature:
            self.get_logger().info('Current temperature is higher than %f: %f' % (self.max_temperature, current_temperature))
            self.send_set_request()
        elif current_temperature < self.min_temperature:
            self.get_logger().info('Current temperature is lower than %f: %f' % (self.min_temperature, current_temperature))
            self.send_set_request()
        else:
            self.get_logger().info('Current temperature is within save bounds: %f' % (current_temperature))


def main(args=None):
    rclpy.init(args=args)
    temperature_display_client = TemperatureControlClient()
    rclpy.spin(temperature_display_client)
    temperature_display_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
