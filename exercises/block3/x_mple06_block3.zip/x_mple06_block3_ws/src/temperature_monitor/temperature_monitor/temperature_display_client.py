from tempmon_interfaces.srv import GetTemperature

import rclpy
from rclpy.node import Node


class TemperatureDisplayClient(Node):

    def __init__(self):
        super().__init__('temperature_display_client')

        self.cli = self.create_client(GetTemperature, 'get_temperature')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = GetTemperature.Request()
        self.future = None  # Initialize the Future to keep track of the response
        self.timer = self.create_timer(2.0, self.timer_callback)
        self.get_logger().info('TemperatureDisplayClient is ready')


    def timer_callback(self):
        if self.future is None:
            self.send_request()
        elif self.future.done():
            self.handle_response(self.future.result())
        else:
            self.get_logger().info('Waiting for response...')


    def send_request(self):
        self.get_logger().info('Sending request...')
        self.future = self.cli.call_async(self.req)


    def handle_response(self, response):
        if response is not None and response.success:
            self.get_logger().info('Current temperature: %f' % (response.current_temperature))
        else:
            self.get_logger().warning('Service call failed or returned an invalid response')
        self.future = None  # Resetting the Future for next call


def main(args=None):
    rclpy.init(args=args)
    temperature_display_client = TemperatureDisplayClient()
    rclpy.spin(temperature_display_client)
    temperature_display_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
