# Aufgabe 6

## a) Paket erstellen

Dieses erstellen wir wie gewohnt im `src` Ordner unseres Working Spaces mit:
```bash
ros2 pkg create --build-type ament_python --license Apache-2.0 temperature_monitor
```

## b) Eigene Service Nachrichten

### Interface Paket

Da eigene Interfaces in einem CMake Paket erstellt werden müssen, erstellen wir auch ein solches:
```bash
ros2 pkg create --build-type ament_cmake --license Apache-2.0 tempmon_interfaces
```
In diesem wird nun ein Ordner für die Service Nachrichten und darin eben auch diese erstellt:

```bash
cd tempmon_interfaces
mkdir srv
cd srv
touch SetTemperature.srv
touch GetTemperature.srv
```

In den Nachrichten-Dateien erstellt man nun die Nachrichten entsprechend der gegebenen Daten:

### `GetTemperature.srv`

```ros
---
float64 current_temperature
bool success
```

### `SetTemperature.srv`

```ros
float64 new_temperature
---
bool success
```

### Build-Datei anpassen

Nun müssen die neuen Nachrichten noch in der `CMakeLists.txt` eingetragen werden, damit man sie verwenden kann. Dazu fügt man folgende Zeilen hinzu:

```txt
find_package(rosidl_default_generators REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
  "srv/GetTemperature.srv"
  "srv/SetTemperature.srv"
)
```

### `package.xml`

Da wir die `rosidl_default_generators` verwenden, müssen wir für diese noch die Abhängigkeiten nachpflegen. Bei dieser Gelegenheit tragen wir auch weitere ein, die später für die Ausführung notwendig sind.

Im `<package>` Element ergänzen wir:

```xml
<buildtool_depend>rosidl_default_generators</buildtool_depend>
<exec_depend>rosidl_default_runtime</exec_depend>
<member_of_group>rosidl_interface_packages</member_of_group>
```

### Bauen

Da das Interface Paket nun so weit fertig ist, können wir ins Hauptverzeichnes unseren Workingspaces wechseln und es schon einmal bauen:

```bash
cd ~/my_ws
colcon build --packages-select tempmon_interfaces
```

### Anpassungen im Haupt-Paket

Damit die neuen Nachrichten auf jeden Fall im `temperature_monitor` verfügbar sind, kann man der dortigen `package.xml` noch folgende Zeile hinzufügen:

```xml
  <exec_depend>tempmon_interfaces</exec_depend>
```

## c) Server erstellen

Hier wird in `ws/temperature_monitor/temperature_monitor` die Datei `temperature_server.py` angelegt.

### `temperature_server.py`

```python
from tempmon_interfaces.srv import GetTemperature, SetTemperature

import random
import rclpy
from rclpy.node import Node


class TemperatureServer(Node):

    def __init__(self):
        super().__init__('temperature_server')
        self.current_temperature = 22.5
        self.get_temperature = self.create_service(GetTemperature, 'get_temperature', self.get_temperature_callback)
        self.set_temperature = self.create_service(SetTemperature, 'set_temperature', self.set_temperature_callback)
        self.timer = self.create_timer(1.0, self.timer_callback)  # one second timer
        self.get_logger().info('TemperatureServer is ready')


    def get_temperature_callback(self, request, response):
        response.current_temperature = self.current_temperature
        self.get_logger().info('Temperature requested - currently at: %f' % (response.current_temperature))
        response.success = True
        return response


    def set_temperature_callback(self, request, response):
        if not isinstance(request.set_temperature, (int, float)):
            response.success = False
            self.get_logger().error('Invalid set_temperature value received: %s' % str(request.set_temperature))
        else:
            self.current_temperature = request.new_temperature
            self.get_logger().info('Setting new temperature to: %f' % (request.new_temperature))
            response.success = True
        return response
    

    def timer_callback(self):
        # changes the temperature randomly between -1.0 and 1.0
        self.current_temperature += (random.random() - 0.5) * 2.0
        self.get_logger().info('Current temperature: %f' % (self.current_temperature))


def main(args=None):
    rclpy.init(args=args)
    temperature_server = TemperatureServer()
    rclpy.spin(temperature_server)
    rclpy.shutdown()


if __name__ == '__main__':
    main()

```

Abschließend muss die Node noch der `setup.py` hinzugefügt werden:

```python
...
entry_points={
        'console_scripts': [
            'temperature_server = temperature_monitor.temperature_server:main',
        ],
    },
...
```

Nun kann man diesen starten per

```bash
ros2 run temperature_monitor temperature_server
```

## d) Clients erstellen

> Das Abfangen von Fehlern, also Teilaufgabe e) lösen wir gleich mit.

Auch hier kann man zunächst die Dateien für die Nodes anlegen:

```bash
cd ws/src/temperature_monitor
touch temperature_control_client.py
touch temperature_display_client.py
```

Füllen wir diese nun mit ihren Funktionen.

### `temperature_display_client.py`

Auf dem Aufgabenzettel steht:
> Dieser Client ruft periodisch die aktuelle Temperatur vom Server ab und gibt sie in der Konsole aus.

Das heißt, dass wir hier nur einen timer laufen lassen, dessen callback dann die Antwort ausgibt.

Hier erfolgt ein periodischer Aufruf, was der Grund sein könnte dass die in den Docs vorgeschlagene Methode `rclpy.spin_until_future_complete(self, self.future)` nicht zu beenden scheint. Dies können wir umgehen, indem wir die essenzielle Funktionalität im Timer callback nachstellen.

```python
from tempmon_interfaces.srv import GetTemperature

import rclpy
from rclpy.node import Node


class TemperatureDisplayClient(Node):

    def __init__(self):
        super().__init__('temperature_display_client')

        self.cli = self.create_client(GetTemperature, 'get_temperature')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = GetTemperature.Request()
        self.future = None  # Initialize the Future to keep track of the response
        self.timer = self.create_timer(2.0, self.timer_callback)
        self.get_logger().info('TemperatureDisplayClient is ready')


    def timer_callback(self):
        if self.future is None:
            self.send_request()
        elif self.future.done():
            self.handle_response(self.future.result())
        else:
            self.get_logger().info('Waiting for response...')


    def send_request(self):
        self.get_logger().info('Sending request...')
        self.future = self.cli.call_async(self.req)


    def handle_response(self, response):
        if response is not None and response.success:
            self.get_logger().info('Current temperature: %f' % (response.current_temperature))
        else:
            self.get_logger().warning('Service call failed or returned an invalid response')
        self.future = None  # Resetting the Future for next call


def main(args=None):
    rclpy.init(args=args)
    temperature_display_client = TemperatureDisplayClient()
    rclpy.spin(temperature_display_client)
    temperature_display_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

```

Hierbei sind sicherlich auch minimalistischere Ansätze möglich - hier wird im _Sync vs Async_ Artikel folgendes genannt:

```python
while rclpy.ok():
    rclpy.spin_once(node)
    if future.done():
        #Get response
```

### `temperature_control_client.py`

Auf dem Aufgabenzettel steht:
> Dieser Client überwacht die Temperatur und fordert eine Änderung an, wenn die Temperatur außerhalb eines vordefinierten Bereichs liegt (20-25°C).

Hier müssen wir also sowohl die Temperatur abfragen, als auch bei bedarf die Temperatur zurück setzen, falls diese außerhalb des sicheren Bereches liegt.

Grundsätzlich handelt es sich bei diesem Client um eine Erweiterung der `_display_client` Node, nur dass hier statt der der einfachen Darstellung der Temperatur eine Überprüfung und ggf. ein Aufruf zur Anpassung der Temperatur erfolgt.

```python
from tempmon_interfaces.srv import GetTemperature, SetTemperature

import rclpy
from rclpy.node import Node


class TemperatureControlClient(Node):

    def __init__(self):
        super().__init__('temperature_control_client')

        self.get_cli = self.create_client(GetTemperature, 'get_temperature')
        self.set_cli = self.create_client(SetTemperature, 'set_temperature')
        while not self.get_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        while not self.set_cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.get_req = GetTemperature.Request()
        self.set_req = SetTemperature.Request()
        self.get_future = None  # Initialize the Futures to keep track of the response
        self.set_future = None

        self.timer = self.create_timer(4.0, self.timer_callback)
        self.min_temperature = 20.0  # Those could alternatively be read from a parameter
        self.max_temperature = 25.0
        self.save_temperature = (self.min_temperature + self.max_temperature) / 2.0
        self.get_logger().info('TemperatureControlClient is ready')


    def timer_callback(self):
        if self.set_future is not None:
            if self.set_future.done():
                self.handle_set_response(self.set_future.result())
            else:
                self.get_logger().info('Waiting for response...')
        elif self.get_future is None:
            self.send_get_request()
        elif self.get_future.done():
            self.handle_get_response(self.get_future.result())
        else:
            self.get_logger().info('Waiting for response...')


    def send_get_request(self):
        self.get_logger().info('Sending request to get temperature...')
        self.get_future = self.get_cli.call_async(self.get_req)


    def send_set_request(self):
        self.get_logger().info('Sending request to set temperature to %f ...' % self.save_temperature)
        self.set_req.new_temperature = self.save_temperature
        self.set_future = self.set_cli.call_async(self.set_req)


    def handle_get_response(self, response):
        if response is None:
            self.get_logger().error('Exception while calling get_temperature service: %s' % self.get_future.exception())
        elif response is not None and response.success:
            self.check_temperature(response.current_temperature)
        else:
            self.get_logger().warning('Service call failed or returned an invalid response')
        self.get_future = None  # Resetting the Future for next call


    def handle_set_response(self, response):
        if response is None:
            self.get_logger().error('Exception while calling set_temperature service: %s' % self.set_future.exception())
        elif response is not None and response.success:
            self.get_logger().info('Temperature set successfully')
        else:
            self.get_logger().warning('Temperature setting failed')
        self.set_future = None  # Resetting the Future for next call


    def check_temperature(self, current_temperature):
        if current_temperature > self.max_temperature:
            self.get_logger().info('Current temperature is higher than %f: %f' % (self.max_temperature, current_temperature))
            self.send_set_request()
        elif current_temperature < self.min_temperature:
            self.get_logger().info('Current temperature is lower than %f: %f' % (self.min_temperature, current_temperature))
            self.send_set_request()
        else:
            self.get_logger().info('Current temperature is within save bounds: %f' % (current_temperature))


def main(args=None):
    rclpy.init(args=args)
    temperature_display_client = TemperatureControlClient()
    rclpy.spin(temperature_display_client)
    temperature_display_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

```

Abschließend werden auch diese Nodes der `setup.py` hinzugefügt:

```python
...
entry_points={
        'console_scripts': [
            'temperature_server = temperature_monitor.temperature_server:main',
            'temperature_display_client = temperature_monitor.temperature_display_client:main',
            'temperature_control_client = temperature_monitor.temperature_control_client:main',
        ],
    },
...
```

Nun kann man diese starten per

```bash
ros2 run temperature_monitor temperature_display_client
# bzw
ros2 run temperature_monitor temperature_control_client
```
